document.addEventListener('DOMContentLoaded', () => {
    const track = document.querySelector('.carousel-track');
    const slides = Array.from(document.querySelectorAll('.carousel-slide'));
    const nextButton = document.querySelector('.next-btn');
    const prevButton = document.querySelector('.prev-btn');
    const indicatorsContainer = document.querySelector('.carousel-indicators');

    let currentIndex = 0;
    let autoFlipTimer = null;
    let isCustomDelayActive = false;

    // 1. Inicializar indicadores (puntos) dinámicamente
    slides.forEach((_, index) => {
        const dot = document.createElement('div');
        dot.classList.add('indicator');
        if (index === 0) dot.classList.add('active');
        dot.addEventListener('click', () => {
            goToSlide(index);
            triggerUserInteraction();
        });
        indicatorsContainer.appendChild(dot);
    });

    const indicators = Array.from(document.querySelectorAll('.indicator'));

    // 2. Función para mover el carrusel a un índice específico
    function goToSlide(index) {
        if (index < 0) {
            currentIndex = slides.length - 1;
        } else if (index >= slides.length) {
            currentIndex = 0;
        } else {
            currentIndex = index;
        }

        // Desplazamiento mediante CSS transform
        track.style.transform = `translateX(-${currentIndex * 100}%)`;

        // Actualizar estado de los indicadores
        indicators.forEach((dot, idx) => {
            dot.classList.toggle('active', idx === currentIndex);
        });
    }

    // 3. Manejo del temporizador (Autoflip) dinámico
    function startAutoFlip(delay = 5000) {
        stopAutoFlip();
        autoFlipTimer = setTimeout(() => {
            goToSlide(currentIndex + 1);
            // Si venía de un delay extendido (10s), vuelve a la normalidad de 5s
            if (isCustomDelayActive) {
                isCustomDelayActive = false;
                startAutoFlip(5000);
            } else {
                startAutoFlip(5000);
            }
        }, delay);
    }

    function stopAutoFlip() {
        if (autoFlipTimer) clearTimeout(autoFlipTimer);
    }

    // Al interactuar se reinicia el contador con penalización de 10 segundos
    function triggerUserInteraction() {
        isCustomDelayActive = true;
        startAutoFlip(10000); 
    }

    // 4. Listeners para los botones de navegación
    nextButton.addEventListener('click', () => {
        goToSlide(currentIndex + 1);
        triggerUserInteraction();
    });

    prevButton.addEventListener('click', () => {
        goToSlide(currentIndex - 1);
        triggerUserInteraction();
    });

    // 5. Soporte para Desplazamiento Táctil (Swipe Mobile)
    let startX = 0;
    let endX = 0;

    track.addEventListener('touchstart', (e) => {
        startX = e.touches[0].clientX;
    }, { passive: true });

    track.addEventListener('touchmove', (e) => {
        endX = e.touches[0].clientX;
    }, { passive: true });

    track.addEventListener('touchend', () => {
        const threshold = 50; // Mínimo de píxeles para detectar el deslizamiento
        if (startX - endX > threshold) {
            // Desplazamiento hacia la izquierda -> Siguiente
            goToSlide(currentIndex + 1);
            triggerUserInteraction();
        } else if (endX - startX > threshold) {
            // Desplazamiento hacia la derecha -> Anterior
            goToSlide(currentIndex - 1);
            triggerUserInteraction();
        }
    });

    // 6. Iniciar el ciclo automático por primera vez (5 segundos)
    startAutoFlip(5000);
});